package com.shop.service;

import java.util.List;

import com.shop.dto.HomeDTO;

public interface HomeService {
	public List<HomeDTO>  HomeViewDAO();
}
