package com.shop.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class detailFoodDTO {

	private String sweet1;//단맛 
	private String sweet2; 
	private String sweet3;
	
	private String salty1;//신맛
	private String salty2;
	private String salty3;
	
	private String sour1;//
	private String sour2;
	private String sour3;
		
	private String density1;//농도
	private String density2;
	private String density3;
}
